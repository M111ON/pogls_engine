#define L38_GPU_SV 34u
#define POGLS_PHI_SCALE (1u<<20)
#include "geo_route.h"
#include "theta_map.h"
#include "ts_pipeline.h"
#include <stdio.h>

/* mock write_fn */
static uint64_t write_sink = 0;
static void mock_write(uint32_t addr, uint64_t value, void *ctx){
    (void)ctx; write_sink ^= addr ^ value;
}

int main(void){
    /* geo_route */
    uint64_t c = 0xDEADBEEF12345678ULL;
    printf("geo_route MAIN:     %s\n", geo_route(c,~c,35)==ROUTE_MAIN?"✓":"✗");
    printf("geo_route TEMPORAL: %s\n", geo_route(c,~c,1)==ROUTE_TEMPORAL?"✓":"✗");
    printf("geo_route DROP:     %s\n", geo_route(c,~c^1,35)==ROUTE_DROP?"✓":"✗");

    /* theta_map */
    uint32_t ti=154752, td=theta_to_dodec(ti);
    printf("theta_verify:       %s\n", theta_verify(ti,td)?"✓":"✗");
    printf("sum=PHI_SCALE:      %s\n", (ti+td==POGLS_PHI_SCALE)?"✓":"✗");

    /* ts_pipeline */
    TSPipeline p; ts_pipeline_init(&p);
    for(int i=0;i<1000;i++){
        uint64_t v=(uint64_t)i*0x9e3779b97f4a7c15ULL;
        ts_write(&p,v,(uint32_t)(v&THETA_MASK),mock_write,NULL);
    }
    printf("ts_write 1k ops:    %s\n", (p.n_main+p.n_temporal+p.n_drop==1000+p.n_main)?"✓":"~");
    printf("  main=%llu temporal=%llu drop=%llu flush=%llu\n",
           (unsigned long long)p.n_main,
           (unsigned long long)p.n_temporal,
           (unsigned long long)p.n_drop,
           (unsigned long long)p.n_flush);
    printf("  sink=%llu\n", (unsigned long long)write_sink);
    printf("All headers: compile ✓\n");
    return 0;
}
