"""
Letter Cube BFS — 6 pairs (a-f, A-F)
State: tuple of 6 faces, each face holds 1 letter
Move: swap any 2 adjacent faces (cube adjacency graph)
Goal: find God's number = max over all states of min moves to "solved"

Cube face indices:
    0=Top, 1=Front, 2=Right, 3=Back, 4=Left, 5=Bottom

Adjacency (each face degree=4):
    Top(0)    ↔ Front(1), Right(2), Back(3), Left(4)
    Bottom(5) ↔ Front(1), Right(2), Back(3), Left(4)
    Front(1)  ↔ Top(0), Right(2), Left(4), Bottom(5)
    Right(2)  ↔ Top(0), Front(1), Back(3), Bottom(5)
    Back(3)   ↔ Top(0), Right(2), Left(4), Bottom(5)
    Left(4)   ↔ Top(0), Front(1), Back(3), Bottom(5)
"""

from collections import deque
from itertools import permutations
import time

# --- Config ---
LETTERS = ['a','A','b','B','c','C','d','D','e','E','f','F']
PAIRS = {
    'a':'A','A':'a','b':'B','B':'b',
    'c':'C','C':'c','d':'D','D':'d',
    'e':'E','E':'e','f':'F','F':'f'
}
N_FACES = 6

# Cube adjacency
ADJ = {
    0: [1,2,3,4],
    1: [0,2,4,5],
    2: [0,1,3,5],
    3: [0,2,4,5],
    4: [0,1,3,5],
    5: [1,2,3,4],
}

def get_moves(state):
    """Swap adjacent faces = 1 move"""
    moves = []
    for f1 in range(N_FACES):
        for f2 in ADJ[f1]:
            if f2 > f1:  # avoid duplicates
                s = list(state)
                s[f1], s[f2] = s[f2], s[f1]
                moves.append(tuple(s))
    return moves

def pair_score(state):
    """Count how many faces have their pair on an adjacent face"""
    score = 0
    for f in range(N_FACES):
        letter = state[f]
        pair = PAIRS[letter]
        for adj_f in ADJ[f]:
            if state[adj_f] == pair:
                score += 1
    return score // 2  # each pair counted twice

def is_solved(state):
    """Solved = every face has its pair on at least 1 adjacent face"""
    return pair_score(state) == N_FACES // 2  # 3 pairs satisfied

# --- BFS from solved states (bidirectional) ---
def bfs_gods_number():
    print("=== Letter Cube BFS — 6 pairs (a-f, A-F) ===\n")
    
    # Find all "solved" states (all 3 pairs adjacent)
    # Use BFS from ALL solved states simultaneously
    
    # First: enumerate all valid states (each letter used exactly once)
    print("Enumerating states...")
    t0 = time.time()
    
    all_states = list(permutations(LETTERS, N_FACES))
    # Each letter used at most once (permutation guarantees unique)
    # But we need each letter from 12 used exactly once on 6 faces
    # Actually: choose 6 from 12 letters, assign to 6 faces
    print(f"  Total permutations P(12,6) = {len(all_states):,}")
    
    # Find solved states
    solved = set()
    for s in all_states:
        if is_solved(s):
            solved.add(s)
    
    print(f"  Solved states (all pairs adjacent): {len(solved):,}")
    print(f"  Enumeration time: {time.time()-t0:.2f}s\n")
    
    # BFS from all solved states simultaneously
    print("Running BFS (multi-source from solved states)...")
    t1 = time.time()
    
    dist = {}
    for s in solved:
        dist[s] = 0
    
    queue = deque(solved)
    depth_counts = {0: len(solved)}
    
    while queue:
        state = queue.popleft()
        d = dist[state]
        
        for nxt in get_moves(state):
            if nxt not in dist:
                dist[nxt] = d + 1
                depth_counts[d+1] = depth_counts.get(d+1, 0) + 1
                queue.append(nxt)
    
    bfs_time = time.time() - t1
    
    gods_number = max(dist.values()) if dist else 0
    reachable = len(dist)
    
    print(f"  BFS time: {bfs_time:.2f}s")
    print(f"  Reachable states: {reachable:,} / {len(all_states):,}")
    print(f"  Coverage: {reachable/len(all_states)*100:.1f}%\n")
    
    print("=== DEPTH DISTRIBUTION ===")
    for d in sorted(depth_counts):
        bar = '█' * min(40, depth_counts[d] // max(1, max(depth_counts.values())//40))
        print(f"  depth {d:2d}: {depth_counts[d]:8,} states  {bar}")
    
    print(f"\n{'='*45}")
    print(f"  GOD'S NUMBER (6 pairs) = {gods_number}")
    print(f"{'='*45}")
    
    # Sample worst case
    worst = [s for s,d in dist.items() if d == gods_number]
    print(f"\n  Worst-case states: {len(worst):,}")
    if worst:
        ex = worst[0]
        print(f"  Example worst state: {ex}")
        print(f"  Pair score: {pair_score(ex)}/3")
    
    return gods_number, depth_counts, dist

if __name__ == "__main__":
    gods_number, depth_counts, dist = bfs_gods_number()
