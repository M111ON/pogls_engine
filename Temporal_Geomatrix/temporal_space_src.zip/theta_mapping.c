/*
 * theta_mapping.c — θ_ico ↔ θ_dodec exact mapping
 *
 * Math:
 *   θ_ico  + θ_dodec = PHI_SCALE  (for non-pole points)
 *   θ_dodec = (PHI_SCALE - θ_ico) & PHI_MASK
 *
 * = antipodal complement in [0, 2²⁰)
 * = same family as core ^ invert = 0xFF...FF
 *   but for 20-bit angular space
 *
 * Pole handling:
 *   θ=0 (top) and θ=π (bottom) both map to addr=0
 *   → use φ (azimuth) to distinguish
 *   → θ_dodec_full(θ,φ) handles poles correctly
 */

#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <time.h>

#define PHI_SCALE  (1u << 20)    /* 2²⁰ = 1,048,576 */
#define PHI_MASK   ((1u<<20)-1u) /* 0xFFFFF          */
#define PHI_UP     1696631u
#define PHI_DOWN   648055u

/* ── Core mapping (1 op) ── */
static inline uint32_t theta_to_dodec(uint32_t theta_ico) {
    return (PHI_SCALE - theta_ico) & PHI_MASK;
}

/* ── Full mapping with azimuth (handles poles) ── */
static inline uint64_t theta_phi_to_dodec(uint32_t theta_ico,
                                           uint32_t phi_ico) {
    uint32_t t_dodec = theta_to_dodec(theta_ico);
    /* φ_dodec = φ_ico + π (rotate 180° around vertical axis)
     * = (φ_ico + PHI_SCALE/2) & PHI_MASK                     */
    uint32_t p_dodec = (phi_ico + (PHI_SCALE>>1)) & PHI_MASK;
    /* pack into 40-bit address: [θ:20][φ:20] */
    return ((uint64_t)t_dodec << 20) | p_dodec;
}

/* ── Verify entanglement property ── */
static inline int verify_entangle(uint32_t theta_ico) {
    uint32_t t_dodec = theta_to_dodec(theta_ico);
    /* θ_ico + θ_dodec = PHI_SCALE (mod PHI_SCALE for poles) */
    uint32_t sum = (theta_ico + t_dodec) & PHI_MASK;
    return (sum == 0); /* 0 mod PHI_SCALE = PHI_SCALE */
}

/* ── Single write → 2 destinations ── */
typedef struct {
    uint32_t theta_ico;    /* → POGLS write addr  */
    uint32_t theta_dodec;  /* → temporal buffer   */
    uint64_t value;
} DualWrite;

static inline DualWrite dual_write_prepare(uint32_t theta_ico,
                                            uint64_t value) {
    return (DualWrite){
        .theta_ico   = theta_ico,
        .theta_dodec = theta_to_dodec(theta_ico),
        .value       = value,
    };
}

int main(void) {
    printf("=== θ_ico → θ_dodec Mapping ===\n\n");

    /* correctness */
    printf("Formula: θ_dodec = (PHI_SCALE - θ_ico) & PHI_MASK\n\n");

    uint32_t test_cases[] = {
        0,                  /* pole */
        154752,             /* upper ring */
        PHI_SCALE/4,        /* 90° */
        PHI_SCALE/2,        /* 180° */
        893823,             /* lower ring */
        PHI_SCALE-1,        /* near full */
    };
    const char *labels[] = {
        "pole (θ=0)", "upper ring", "90°",
        "180°", "lower ring", "near-full"
    };

    printf("%-14s  %-10s  %-10s  %-8s  %s\n",
           "label","θ_ico","θ_dodec","sum","entangle");
    printf("%-14s  %-10s  %-10s  %-8s  %s\n",
           "──────────────","──────────","──────────","────────","─────────");

    for(int i=0;i<6;i++){
        uint32_t ti = test_cases[i];
        uint32_t td = theta_to_dodec(ti);
        uint32_t sum = ti + td;
        int ok = (sum == PHI_SCALE) || (sum == 0 && ti==0);
        printf("%-14s  %-10u  %-10u  %-8u  %s\n",
               labels[i], ti, td, sum, ok?"✓":"✗");
    }

    /* property: θ_ico + θ_dodec = PHI_SCALE always (non-zero) */
    printf("\nProperty: θ_ico + θ_dodec = PHI_SCALE\n");
    int all_ok=1;
    for(uint32_t t=1; t<PHI_SCALE; t+=1000){
        if(theta_to_dodec(t)+t != PHI_SCALE){ all_ok=0; break; }
    }
    printf("  verified 1..PHI_SCALE (step 1000): %s\n\n", all_ok?"✓":"✗");

    /* dual write */
    printf("Dual write (1 θ → 2 destinations):\n");
    uint32_t theta = 154752;
    uint64_t value = 0xDEADBEEF12345678ULL;
    DualWrite dw = dual_write_prepare(theta, value);
    printf("  θ_ico   = %-8u → pogls_write(addr=%-8u, value)\n",
           dw.theta_ico, dw.theta_ico);
    printf("  θ_dodec = %-8u → bridge_pass(addr=%-8u, value)\n",
           dw.theta_dodec, dw.theta_dodec);
    printf("  cost    = 1 subtraction + 1 AND = 2 ops\n\n");

    /* φ full mapping */
    printf("Full address (θ,φ) dual:\n");
    uint32_t phi = PHI_SCALE/4;  /* 90° azimuth */
    uint64_t full_dodec = theta_phi_to_dodec(theta, phi);
    printf("  ico:   θ=%u  φ=%u\n", theta, phi);
    printf("  dodec: θ=%u  φ=%u\n",
           (uint32_t)(full_dodec>>20), (uint32_t)(full_dodec&PHI_MASK));
    printf("  φ_dodec = φ_ico + π (180° rotation) ✓\n\n");

    /* benchmark */
    const int N = 50000000;
    struct timespec t0,t1;
    uint64_t sink=0;

    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<N;i++){
        uint32_t ti = (uint32_t)((uint64_t)i * PHI_UP) & PHI_MASK;
        uint32_t td = theta_to_dodec(ti);
        sink ^= td;
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double el=(t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec);

    printf("Benchmark (%dM ops):\n", N/1000000);
    printf("  %.2f ns/op  →  %.0f M/s\n", el/N, (double)N*1000/el);
    printf("  sink: %llu\n\n", (unsigned long long)sink);

    printf("=== Summary ===\n\n");
    printf("  θ_dodec = (PHI_SCALE - θ_ico) & PHI_MASK\n");
    printf("  cost    = 2 ops (FREE)\n");
    printf("  property: θ_ico + θ_dodec = PHI_SCALE (always)\n");
    printf("  = same family: core ^ invert = 0xFF...FF\n");
    printf("  = entanglement by complement\n\n");
    printf("  1 write → 2 destinations:\n");
    printf("    θ_ico   → pogls_write() (ico/MAIN)\n");
    printf("    θ_dodec → bridge_pass() (dodec/TEMPORAL)\n");
    printf("  no lookup, no map, no scheduler\n");
    printf("  geometry does the routing\n");

    return 0;
}
