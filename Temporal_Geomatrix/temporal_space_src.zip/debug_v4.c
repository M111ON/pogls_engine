#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#define N_FACES  6
#define N_MOVES  12
#define ISLAND   720
#define WORDS    12
#define FACE_BITS 6
#define FACE_MASK 0x3FULL

static inline uint64_t get_face(uint64_t s,int f){return(s>>(f*FACE_BITS))&FACE_MASK;}
static inline uint64_t set_face(uint64_t s,int f,uint64_t v){
    return(s&~(FACE_MASK<<(f*FACE_BITS)))|(v<<(f*FACE_BITS));}

static const int MOVES[N_MOVES][2]={{0,1},{0,2},{0,3},{0,4},{5,1},{5,2},{5,3},{5,4},{1,2},{2,3},{3,4},{4,1}};
static inline uint64_t apply_move(uint64_t s,int m){
    int f1=MOVES[m][0],f2=MOVES[m][1];
    uint64_t a=get_face(s,f1),b=get_face(s,f2);
    return set_face(set_face(s,f1,b),f2,a);}

#define HT2 1024
#define HM2 (HT2-1)
static uint64_t hmap_key[HT2];
static uint16_t hmap_val[HT2];
static void hmap_clear(void){memset(hmap_key,0xFF,sizeof(hmap_key));}
static void hmap_put(uint64_t k,uint16_t v){
    uint32_t h=(uint32_t)((k*0x9e3779b97f4a7c15ULL)>>54)&HM2;
    while(hmap_key[h]!=0xFFFFFFFFFFFFFFFFULL)h=(h+1)&HM2;
    hmap_key[h]=k;hmap_val[h]=v;}
static uint16_t hmap_get(uint64_t k){
    uint32_t h=(uint32_t)((k*0x9e3779b97f4a7c15ULL)>>54)&HM2;
    while(hmap_key[h]!=k)h=(h+1)&HM2;
    return hmap_val[h];}

static uint64_t island_states[ISLAND];
static uint16_t adj[ISLAND][N_MOVES];
static uint8_t  perm_buf[6];
static int      island_size;

static void gen_perms(uint8_t *letters,int n,int depth,uint64_t partial,int *idx){
    if(depth==6){island_states[(*idx)++]=partial;return;}
    for(int i=0;i<n;i++){
        if(!perm_buf[i]){
            perm_buf[i]=1;
            gen_perms(letters,n,depth+1,set_face(partial,depth,letters[i]),idx);
            perm_buf[i]=0;
        }
    }
}

static void build_island(uint64_t start){
    uint8_t letters[6];
    for(int f=0;f<6;f++) letters[f]=(uint8_t)get_face(start,f);
    island_size=0;
    memset(perm_buf,0,6);
    gen_perms(letters,6,0,0,&island_size);
    hmap_clear();
    for(int i=0;i<ISLAND;i++) hmap_put(island_states[i],(uint16_t)i);
    for(int i=0;i<ISLAND;i++)
        for(int m=0;m<N_MOVES;m++)
            adj[i][m]=hmap_get(apply_move(island_states[i],m));
}

typedef uint64_t Bits[WORDS];
static inline void bits_set(Bits b,int i){b[i>>6]|=(1ULL<<(i&63));}
static inline int  bits_get(Bits b,int i){return(b[i>>6]>>(i&63))&1;}
static inline int  bits_any(const Bits b){for(int w=0;w<WORDS;w++)if(b[w])return 1;return 0;}

static int bitset_bfs(int si,int dc[16]){
    Bits visited={0},frontier={0},next={0};
    bits_set(visited,si); bits_set(frontier,si);
    int depth=0,gods=0;
    while(bits_any(frontier)){
        if(dc){int c=0;for(int w=0;w<WORDS;w++)c+=__builtin_popcountll(frontier[w]);dc[depth]+=c;}
        gods=depth;
        memset(next,0,sizeof(next));
        for(int i=0;i<ISLAND;i++){
            if(!bits_get(frontier,i))continue;
            for(int m=0;m<N_MOVES;m++){
                int nb=adj[i][m];
                if(!bits_get(visited,nb)){bits_set(next,nb);bits_set(visited,nb);}
            }
        }
        memcpy(frontier,next,sizeof(Bits));
        depth++;
        if(depth>20){printf("STUCK at depth %d\n",depth);break;} // safety
    }
    return gods;
}

int main(void){
    // Build island from known state: a=0,A=1,b=2,B=3,c=4,C=5
    uint64_t start=0;
    for(int f=0;f<6;f++) start=set_face(start,f,f*2); // a,b,c,d,e,f on faces
    build_island(start);
    printf("Island size: %d\n", island_size);

    // BFS from index 0
    int dc[16]={0};
    int g=bitset_bfs(0,dc);
    printf("God's number: %d\n",g);
    printf("Depth dist:\n");
    for(int d=0;d<16;d++) if(dc[d]) printf("  depth %d: %d\n",d,dc[d]);

    // Speed: 10000 trials
    struct timespec t0,t1;
    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<10000;i++) bitset_bfs(i%ISLAND,NULL);
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double el=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)*1e-9;
    printf("\n10k trials: %.3f ms\n",el*1000);
    printf("Per island: %.2f µs\n",el/10000*1e6);
    printf("Throughput: %.2f M states/sec\n",(10000.0*720/el)/1e6);
    return 0;
}
