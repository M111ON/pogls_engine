/*
 * Letter Cube BFS v5 — Bitset + 4-thread parallel
 * Each thread processes independent islands (no shared state)
 * Island struct is thread-local (stack allocated)
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

#define N_FACES   6
#define N_MOVES   12
#define ISLAND    720
#define WORDS     12
#define FACE_BITS 6
#define FACE_MASK 0x3FULL
#define N_THREADS 4
#define TRIALS_TOTAL 1000000

/* ── Encoding ── */
static inline uint64_t get_face(uint64_t s,int f){return(s>>(f*FACE_BITS))&FACE_MASK;}
static inline uint64_t set_face(uint64_t s,int f,uint64_t v){
    return(s&~(FACE_MASK<<(f*FACE_BITS)))|(v<<(f*FACE_BITS));}

static const int MOVES[N_MOVES][2]={
    {0,1},{0,2},{0,3},{0,4},
    {5,1},{5,2},{5,3},{5,4},
    {1,2},{2,3},{3,4},{4,1}};

static inline uint64_t apply_move(uint64_t s,int m){
    int f1=MOVES[m][0],f2=MOVES[m][1];
    uint64_t a=get_face(s,f1),b=get_face(s,f2);
    return set_face(set_face(s,f1,b),f2,a);}

/* ── Per-thread island context (stack, cache-friendly) ── */
typedef struct {
    uint64_t states[ISLAND];
    uint16_t adj[ISLAND][N_MOVES];
    uint64_t hmap_key[1024];
    uint16_t hmap_val[1024];
} IslandCtx;

static void hmap_clear(IslandCtx *ctx){memset(ctx->hmap_key,0xFF,sizeof(ctx->hmap_key));}
static void hmap_put(IslandCtx *ctx,uint64_t k,uint16_t v){
    uint32_t h=(uint32_t)((k*0x9e3779b97f4a7c15ULL)>>54)&1023;
    while(ctx->hmap_key[h]!=0xFFFFFFFFFFFFFFFFULL)h=(h+1)&1023;
    ctx->hmap_key[h]=k;ctx->hmap_val[h]=v;}
static uint16_t hmap_get(IslandCtx *ctx,uint64_t k){
    uint32_t h=(uint32_t)((k*0x9e3779b97f4a7c15ULL)>>54)&1023;
    while(ctx->hmap_key[h]!=k)h=(h+1)&1023;
    return ctx->hmap_val[h];}

static uint8_t perm_buf[6];
static void gen_perms(IslandCtx *ctx,uint8_t *letters,int n,int depth,uint64_t partial,int *idx){
    if(depth==6){ctx->states[(*idx)++]=partial;return;}
    for(int i=0;i<n;i++){
        if(!perm_buf[i]){
            perm_buf[i]=1;
            gen_perms(ctx,letters,n,depth+1,set_face(partial,depth,letters[i]),idx);
            perm_buf[i]=0;
        }
    }
}

static void build_island(IslandCtx *ctx, uint64_t start){
    uint8_t letters[6];
    for(int f=0;f<6;f++) letters[f]=(uint8_t)get_face(start,f);
    int sz=0;
    memset(perm_buf,0,6);
    gen_perms(ctx,letters,6,0,0,&sz);
    hmap_clear(ctx);
    for(int i=0;i<ISLAND;i++) hmap_put(ctx,(uint64_t)ctx->states[i],(uint16_t)i);
    for(int i=0;i<ISLAND;i++)
        for(int m=0;m<N_MOVES;m++)
            ctx->adj[i][m]=hmap_get(ctx,apply_move(ctx->states[i],m));
}

/* ── Bitset BFS ── */
typedef uint64_t Bits[WORDS];
static inline void bset(Bits b,int i){b[i>>6]|=(1ULL<<(i&63));}
static inline int  bget(Bits b,int i){return(b[i>>6]>>(i&63))&1;}
static inline int  bany(const Bits b){for(int w=0;w<WORDS;w++)if(b[w])return 1;return 0;}

static int bitset_bfs(IslandCtx *ctx, int si, int dc[16]){
    Bits visited={0},frontier={0},next={0};
    bset(visited,si); bset(frontier,si);
    int depth=0,gods=0;
    while(bany(frontier)){
        if(dc){int c=0;for(int w=0;w<WORDS;w++)c+=__builtin_popcountll(frontier[w]);dc[depth]+=c;}
        gods=depth;
        memset(next,0,sizeof(next));
        for(int i=0;i<ISLAND;i++){
            if(!bget(frontier,i))continue;
            for(int m=0;m<N_MOVES;m++){
                int nb=ctx->adj[i][m];
                if(!bget(visited,nb)){bset(next,nb);bset(visited,nb);}
            }
        }
        memcpy(frontier,next,sizeof(Bits));
        depth++;
    }
    return gods;
}

/* ── xoshiro256** per-thread RNG ── */
typedef struct { uint64_t s[4]; } RNG;
static inline uint64_t rotl64(uint64_t x,int k){return(x<<k)|(x>>(64-k));}
static inline uint64_t rng_next(RNG *r){
    uint64_t res=rotl64(r->s[1]*5,7)*9;
    uint64_t t=r->s[1]<<17;
    r->s[2]^=r->s[0];r->s[3]^=r->s[1];r->s[1]^=r->s[2];r->s[0]^=r->s[3];
    r->s[2]^=t;r->s[3]=rotl64(r->s[3],45);
    return res;}

static uint64_t make_state(RNG *r, int np){
    uint8_t pool[52];
    for(int i=0;i<2*np;i++) pool[i]=i;
    for(int i=0;i<N_FACES;i++){
        int j=i+(int)(rng_next(r)%(2*np-i));
        uint8_t t=pool[i];pool[i]=pool[j];pool[j]=t;
    }
    uint64_t s=0;
    for(int f=0;f<N_FACES;f++) s=set_face(s,f,pool[f]);
    return s;
}

/* ── Thread worker ── */
typedef struct {
    int  thread_id;
    int  trials;
    double elapsed;
    int  dc[16];
} WorkerArg;

static void *worker(void *arg){
    WorkerArg *w=(WorkerArg*)arg;
    RNG rng; rng.s[0]=0xdeadbeef^w->thread_id; rng.s[1]=0xcafe1234+(uint64_t)w->thread_id*7;
    rng.s[2]=0x12345678*(w->thread_id+1); rng.s[3]=0xabcdef01^(uint64_t)w->thread_id*13;

    IslandCtx *ctx=(IslandCtx*)malloc(sizeof(IslandCtx));

    /* Build island once (all structurally same, just different labels) */
    uint64_t first=make_state(&rng,26);
    build_island(ctx,first);
    int first_idx=hmap_get(ctx,first);

    /* Warmup */
    for(int i=0;i<1000;i++) bitset_bfs(ctx,(i*7)%ISLAND,NULL);

    struct timespec t0,t1;
    clock_gettime(CLOCK_MONOTONIC,&t0);

    for(int i=0;i<w->trials;i++){
        /* rotate start index — same island, different starting points */
        int si=(first_idx + i*13) % ISLAND;
        bitset_bfs(ctx, si, (i<100000)?w->dc:NULL);
    }

    clock_gettime(CLOCK_MONOTONIC,&t1);
    w->elapsed=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)*1e-9;
    free(ctx);
    return NULL;
}

int main(void){
    struct timespec t0,t1;
    printf("=== Letter Cube BFS v5 — Bitset + %d Threads ===\n\n", N_THREADS);

    /* Single-thread baseline first */
    {
        IslandCtx *ctx=(IslandCtx*)malloc(sizeof(IslandCtx));
        uint64_t s0=set_face(set_face(set_face(set_face(set_face(set_face(0,0,0),1,1),2,2),3,3),4,4),5,5);
        build_island(ctx,s0);
        /* warmup */
        for(int i=0;i<5000;i++) bitset_bfs(ctx,i%ISLAND,NULL);
        clock_gettime(CLOCK_MONOTONIC,&t0);
        for(int i=0;i<TRIALS_TOTAL;i++) bitset_bfs(ctx,i%ISLAND,NULL);
        clock_gettime(CLOCK_MONOTONIC,&t1);
        double el=(t1.tv_sec-t0.tv_sec)+(t1.tv_nsec-t0.tv_nsec)*1e-9;
        double ss=(double)TRIALS_TOTAL*720/el;
        printf("Single-thread:\n");
        printf("  Per island:  %.2f µs\n",el/TRIALS_TOTAL*1e6);
        printf("  Throughput:  %.2f M states/sec\n\n",ss/1e6);
        free(ctx);
    }

    /* Multi-thread */
    pthread_t threads[N_THREADS];
    WorkerArg args[N_THREADS];
    int per_thread = TRIALS_TOTAL / N_THREADS;

    for(int t=0;t<N_THREADS;t++){
        args[t].thread_id=t; args[t].trials=per_thread;
        memset(args[t].dc,0,sizeof(args[t].dc));
        pthread_create(&threads[t],NULL,worker,&args[t]);
    }
    for(int t=0;t<N_THREADS;t++) pthread_join(threads[t],NULL);

    /* Aggregate */
    double max_elapsed=0;
    int dc_total[16]={0};
    for(int t=0;t<N_THREADS;t++){
        if(args[t].elapsed>max_elapsed) max_elapsed=args[t].elapsed;
        for(int d=0;d<16;d++) dc_total[d]+=args[t].dc[d];
    }
    double ss_mt=(double)TRIALS_TOTAL*720/max_elapsed;

    printf("%d-thread parallel:\n",N_THREADS);
    printf("  Per island:  %.2f µs\n",max_elapsed/TRIALS_TOTAL*1e6*N_THREADS);
    printf("  Throughput:  %.2f M states/sec\n\n",ss_mt/1e6);

    printf("Depth distribution (400k islands × %d threads):\n",N_THREADS);
    long total_states=0;
    for(int d=0;d<16;d++) total_states+=dc_total[d];
    for(int d=0;d<16;d++){
        if(!dc_total[d])continue;
        printf("  depth %d: %9d  [%5.2f%%]\n",d,dc_total[d],dc_total[d]*100.0/total_states);
    }

    printf("\n=== Full Evolution ===\n");
    printf("  Python BFS        →   0.32 M/s    (1x)\n");
    printf("  C queue BFS       →   5.97 M/s    (18.7x)\n");
    printf("  C bitset 1-thread →  27.25 M/s    (85x)\n");
    printf("  C bitset %d-thread →  %5.2f M/s    (%.0fx)\n",
           N_THREADS, ss_mt/1e6, ss_mt/0.32e6);
    printf("  POGLS target      →  13.60 M/s\n");
    printf("  Headroom vs POGLS →  %.1fx\n", ss_mt/13.6e6);
    return 0;
}
