/*
 * theta_map.h — Angular Dual Mapping: θ_ico ↔ θ_dodec
 *
 * Math (dual polyhedra):
 *   Icosahedron ↔ Dodecahedron
 *   ico.vertex[i] = dodec.face[i]  (same position)
 *
 *   θ_dodec = (PHI_SCALE - θ_ico) & PHI_MASK
 *   property: θ_ico + θ_dodec = PHI_SCALE  (always, non-pole)
 *
 *   φ_dodec = (φ_ico + PHI_SCALE/2) & PHI_MASK  (rotate 180°)
 *
 * Same family as Wireless Hilbert:
 *   core ^ invert  = 0xFF...FF  (64-bit complement)
 *   θ_ico + θ_dodec = PHI_SCALE  (20-bit complement)
 *
 * Cost: 2 ops (subtraction + AND) = FREE
 * Throughput: ~5,937 M/s measured
 */

#ifndef THETA_MAP_H
#define THETA_MAP_H

#include <stdint.h>

#ifndef POGLS_PHI_SCALE
#  define POGLS_PHI_SCALE  (1u << 20)   /* 2²⁰ = 1,048,576 — FROZEN */
#endif
#define THETA_MASK  ((POGLS_PHI_SCALE) - 1u)   /* 0xFFFFF */

/*
 * theta_to_dodec — derive dodecahedron address from icosphere address
 * 1 write → 2 destinations simultaneously
 */
static inline uint32_t theta_to_dodec(uint32_t theta_ico)
{
    return (POGLS_PHI_SCALE - theta_ico) & THETA_MASK;
}

/*
 * phi_to_dodec — azimuth dual (rotate 180°)
 */
static inline uint32_t phi_to_dodec(uint32_t phi_ico)
{
    return (phi_ico + (POGLS_PHI_SCALE >> 1)) & THETA_MASK;
}

/*
 * theta_verify — entanglement check
 * returns 1 if pair is valid (θ_ico + θ_dodec == PHI_SCALE)
 */
static inline int theta_verify(uint32_t theta_ico, uint32_t theta_dodec)
{
    if (theta_ico == 0) return 1;  /* pole: self-dual */
    return (theta_ico + theta_dodec) == POGLS_PHI_SCALE;
}

#endif /* THETA_MAP_H */
