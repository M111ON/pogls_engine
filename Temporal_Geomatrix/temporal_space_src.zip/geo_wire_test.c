/*
 * geo_wire_test.c
 * geo_route (Wireless Hilbert) wired BEFORE geo_net_route
 *
 * Pipeline:
 *   [input] → geo_route (XOR+bit0) → DROP/MAIN/TEMPORAL
 *                                         ↓
 *                                   geo_net_route (cylinder map)
 *                                         ↓
 *                                   QRPN (verify, still runs)
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

/* ── geo_route (Wireless Hilbert) ── */
typedef enum { ROUTE_DROP=0, ROUTE_MAIN=1, ROUTE_TEMPORAL=2 } route_t;

static inline route_t geo_route(uint64_t core, uint64_t inv, uint64_t addr) {
    if ((core ^ inv) != 0xFFFFFFFFFFFFFFFFULL) return ROUTE_DROP;
    return (addr & 1) ? ROUTE_MAIN : ROUTE_TEMPORAL;
}

/* ── geo_net_route (stub — cylinder map) ── */
/* simplified: replicate spoke/slot logic without full headers */
#define CYL_FULL_N  3456u
#define CYL_SPOKES  6u

typedef struct {
    uint8_t  spoke;
    uint16_t slot;
    uint8_t  face;
    uint8_t  inv_spoke;
    route_t  destination;  /* NEW: MAIN or TEMPORAL */
} GeoNetAddr;

static inline uint8_t _gn_mod6(uint32_t n) {
    uint32_t q=(n*10923U)>>16; return (uint8_t)(n-q*6U);
}

static inline GeoNetAddr geo_net_route_wired(
    uint64_t core, uint64_t inv, uint64_t addr)
{
    GeoNetAddr out = {0};

    /* Step 1: Wireless Hilbert gate (zero-cost) */
    route_t dest = geo_route(core, inv, addr);
    if (dest == ROUTE_DROP) {
        out.destination = ROUTE_DROP;
        return out;
    }

    /* Step 2: cylinder mapping (unchanged from geo_net_route) */
    uint16_t full_idx = (uint16_t)(addr % CYL_FULL_N);
    uint8_t  spoke    = _gn_mod6(full_idx);
    uint16_t slot     = full_idx / CYL_SPOKES;
    uint8_t  inv_s    = (spoke + 3) % 6;

    out.spoke       = spoke;
    out.slot        = slot;
    out.face        = (uint8_t)(slot / 64);
    out.inv_spoke   = inv_s;
    out.destination = dest;   /* MAIN or TEMPORAL */

    return out;
}

/* ── Pipeline simulation ── */
typedef struct {
    uint64_t total;
    uint64_t dropped;
    uint64_t to_main;
    uint64_t to_temporal;
    uint64_t qrpn_calls;   /* only called when NOT dropped */
} PipelineStats;

static inline void pipeline_process(
    uint64_t core, uint64_t inv, uint64_t addr,
    PipelineStats *s)
{
    s->total++;
    GeoNetAddr a = geo_net_route_wired(core, inv, addr);

    if (a.destination == ROUTE_DROP) {
        s->dropped++;
        return;   /* QRPN never called — saved */
    }

    /* QRPN would run here */
    s->qrpn_calls++;

    if (a.destination == ROUTE_MAIN)     s->to_main++;
    else                                  s->to_temporal++;
}

int main(void) {
    struct timespec t0,t1;
    printf("=== Wireless Hilbert wired into geo_net_route ===\n\n");

    /* ── Correctness ── */
    printf("Correctness:\n");
    uint64_t c = 0xDEADBEEF12345678ULL;

    GeoNetAddr r1 = geo_net_route_wired(c, ~c, 0x101); /* odd  → MAIN */
    GeoNetAddr r2 = geo_net_route_wired(c, ~c, 0x100); /* even → TEMPORAL */
    GeoNetAddr r3 = geo_net_route_wired(c, ~c^1, 0x101); /* corrupt → DROP */

    printf("  addr=odd  → dest=%s  spoke=%d  slot=%d\n",
           r1.destination==ROUTE_MAIN?"MAIN ✓":"FAIL", r1.spoke, r1.slot);
    printf("  addr=even → dest=%s  spoke=%d  slot=%d\n",
           r2.destination==ROUTE_TEMPORAL?"TEMPORAL ✓":"FAIL", r2.spoke, r2.slot);
    printf("  corrupt   → dest=%s\n",
           r3.destination==ROUTE_DROP?"DROP ✓":"FAIL");

    /* twin: addr ↔ ~addr always opposite */
    uint64_t a1=0xABCDEF01ULL, a2=~a1;
    printf("  twin: addr=%llx→%s  ~addr=%llx→%s  opposite=%s\n",
           (unsigned long long)a1, (a1&1)?"MAIN":"TEMPORAL",
           (unsigned long long)a2, (a2&1)?"MAIN":"TEMPORAL",
           ((a1&1)!=(a2&1))?"✓":"✗");

    /* ── Benchmark ── */
    const int N = 20000000;
    PipelineStats s = {0};

    /* inject 5% corrupt blocks */
    printf("\nBenchmark (%dM ops, 5%% corrupt):\n", N/1000000);

    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<N;i++){
        uint64_t core = (uint64_t)i * 0x9e3779b97f4a7c15ULL;
        uint64_t inv  = (i % 20 == 0) ? ~core^1ULL : ~core; /* 5% corrupt */
        uint64_t addr = (uint64_t)i * 0xBF58476D1CE4E5B9ULL;
        pipeline_process(core, inv, addr, &s);
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);

    double el = (t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec);
    double ns_per_op = el / N;

    printf("  total:     %llu\n", (unsigned long long)s.total);
    printf("  dropped:   %llu  (%.1f%%) ← QRPN saved\n",
           (unsigned long long)s.dropped,
           s.dropped*100.0/s.total);
    printf("  to_main:   %llu  (%.1f%%)\n",
           (unsigned long long)s.to_main,
           s.to_main*100.0/s.total);
    printf("  to_temporal: %llu  (%.1f%%)\n",
           (unsigned long long)s.to_temporal,
           s.to_temporal*100.0/s.total);
    printf("  qrpn_calls: %llu  (%.1f%% of total)\n",
           (unsigned long long)s.qrpn_calls,
           s.qrpn_calls*100.0/s.total);
    printf("  ns/op:     %.2f\n", ns_per_op);
    printf("  throughput: %.2f M/s\n\n", 1000.0/ns_per_op);

    printf("=== Pipeline comparison ===\n");
    printf("  OLD: every op → L3 compute → QRPN\n");
    printf("  NEW: corrupt → DROP (no QRPN)\n");
    printf("       clean   → geo_net → QRPN\n");
    printf("  QRPN load reduction: %.1f%%\n",
           s.dropped*100.0/s.total);
    printf("  Router: deterministic, 3 ops, no PHI\n");
    printf("  twin (a↔A): guaranteed by ~addr\n");

    return 0;
}
