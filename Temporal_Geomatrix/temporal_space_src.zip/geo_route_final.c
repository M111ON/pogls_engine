#include <stdio.h>
#include <stdint.h>
#include <time.h>

typedef enum {
    ROUTE_DROP     = 0,
    ROUTE_MAIN     = 1,
    ROUTE_TEMPORAL = 2,
} route_t;

/* ── Final form (GPT + Po) ── */
static inline route_t geo_route(uint64_t core, uint64_t inv, uint64_t addr) {
    if ((core ^ inv) != 0xFFFFFFFFFFFFFFFFULL)
        return ROUTE_DROP;
    return (addr & 1) ? ROUTE_MAIN : ROUTE_TEMPORAL;
}

/* ── Old L3 (for comparison) ── */
#define PHI_UP   1696631u
#define PHI_DOWN 648055u
#define PHI_SCALE (1u<<20)
#define SMALL_T  128u
#define LARGE_T  1024u

static route_t l3_route_old(uint64_t value, uint32_t addr, uint32_t prev) {
    uint32_t a = (uint32_t)((value * PHI_UP)  >> 20) & 0xFFFFF;
    uint32_t b = (uint32_t)((value * PHI_DOWN) >> 20) & 0xFFFFF;
    uint32_t r = a*a + b*b;
    if (r > (uint32_t)(4*PHI_SCALE)) return ROUTE_DROP;
    uint32_t diff = (a>b)?(a-b):(b-a);
    if (diff < 1024) return ROUTE_MAIN;
    uint32_t delta = (addr>prev)?(addr-prev):(prev-addr);
    int f_phi   = (delta>=PHI_DOWN-8192 && delta<=PHI_DOWN+8192);
    int f_local = (delta < SMALL_T);
    int f_ghost = (delta >= LARGE_T) && !f_phi;
    return ((f_phi||f_local)&&!f_ghost) ? ROUTE_MAIN : ROUTE_TEMPORAL;
}

int main(void) {
    struct timespec t0,t1;
    const int N = 20000000;
    uint64_t sink = 0;

    printf("=== geo_route() final form ===\n\n");

    /* correctness */
    printf("Correctness:\n");
    uint64_t c1 = 0xDEADBEEF12345678ULL;
    printf("  good block, addr=1 → %s\n",
           geo_route(c1,~c1,1)==ROUTE_MAIN?"MAIN ✓":"FAIL");
    printf("  good block, addr=2 → %s\n",
           geo_route(c1,~c1,2)==ROUTE_TEMPORAL?"TEMPORAL ✓":"FAIL");
    printf("  corrupt inv, addr=1 → %s\n",
           geo_route(c1,~c1^0x1ULL,1)==ROUTE_DROP?"DROP ✓":"FAIL");

    /* twin mirror */
    uint64_t addr = 0xABCDEF01ULL;
    uint64_t twin = ~addr;
    printf("  addr=0x%llx  twin=0x%llx\n",
           (unsigned long long)addr, (unsigned long long)twin);
    printf("  addr bit0=%llu → %s\n", addr&1,
           (addr&1)?"MAIN":"TEMPORAL");
    printf("  twin bit0=%llu → %s\n", twin&1,
           (twin&1)?"MAIN":"TEMPORAL");
    printf("  → always opposite ✓ (a↔A guaranteed)\n\n");

    /* benchmark new */
    clock_gettime(CLOCK_MONOTONIC,&t0);
    int cnt[3]={0};
    for(int i=0;i<N;i++){
        uint64_t c=(uint64_t)i*0x9e3779b97f4a7c15ULL;
        route_t r=geo_route(c,~c,(uint64_t)i);
        cnt[r]++; sink^=r;
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double new_ns=((t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec))/N;

    /* benchmark old */
    clock_gettime(CLOCK_MONOTONIC,&t0);
    int cnt2[3]={0};
    for(int i=0;i<N;i++){
        uint64_t c=(uint64_t)i*0x9e3779b97f4a7c15ULL;
        uint32_t a=(uint32_t)(c>>20)&0xFFFFF;
        route_t r=l3_route_old(c,a,a^0xFF);
        cnt2[r]++; sink^=r;
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double old_ns=((t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec))/N;

    printf("Benchmark (%dM ops):\n",N/1000000);
    printf("  geo_route (new): %5.2f ns/op\n",new_ns);
    printf("    MAIN=%d  TEMPORAL=%d  DROP=%d\n",
           cnt[ROUTE_MAIN],cnt[ROUTE_TEMPORAL],cnt[ROUTE_DROP]);
    printf("  L3 old:          %5.2f ns/op\n",old_ns);
    printf("  Speedup: %.1fx\n\n",old_ns/new_ns);

    printf("Distribution:\n");
    printf("  MAIN/TEMPORAL split = %d/%d (addr LSB ~50/50) ✓\n",
           cnt[ROUTE_MAIN],cnt[ROUTE_TEMPORAL]);
    printf("  DROP = %d (only corrupt blocks)\n\n",cnt[ROUTE_DROP]);

    printf("=== Summary ===\n");
    printf("  ~%.0f ops → deterministic, no PHI, no score\n",(double)N);
    printf("  Router ≠ Validator (SHADOW/anomaly → QRPN)\n");
    printf("  twin = ~addr → a↔A always opposite path\n");
    printf("  sink: %llu\n",(unsigned long long)sink);
    return 0;
}
