#include <stdio.h>
#include <stdint.h>
#include <time.h>

#define PHI_UP      1696631u
#define PHI_SCALE   (1u << 20)
#define L38_GPU_SV  34u
#define L38_GPU_BASE 1u

typedef enum { ROUTE_DROP=0, ROUTE_MAIN=1, ROUTE_TEMPORAL=2 } route_t;

/* ── v1: addr & 1 (broken for POGLS38) ── */
static inline route_t geo_route_v1(uint64_t core, uint64_t inv, uint64_t addr) {
    if ((core ^ inv) != 0xFFFFFFFFFFFFFFFFULL) return ROUTE_DROP;
    return (addr & 1) ? ROUTE_MAIN : ROUTE_TEMPORAL;
}

/* ── v2: (addr / SV) & 1 — follows step rhythm ── */
static inline route_t geo_route_v2(uint64_t core, uint64_t inv, uint64_t addr) {
    if ((core ^ inv) != 0xFFFFFFFFFFFFFFFFULL) return ROUTE_DROP;
    return ((addr / L38_GPU_SV) & 1) ? ROUTE_MAIN : ROUTE_TEMPORAL;
}

static inline uint64_t make_addr(uint32_t i) {
    return (uint64_t)L38_GPU_BASE + (uint64_t)L38_GPU_SV * i;
}
static inline uint64_t make_value(uint64_t addr) {
    return ((addr & (PHI_SCALE-1)) * (uint64_t)PHI_UP) >> 20;
}

int main(void) {
    const int N = 10000000;
    printf("=== geo_route v2: (addr/SV)&1 ===\n\n");

    /* correctness: first 10 addrs */
    printf("First 10 addresses:\n");
    printf("  %-6s  %-8s  %-6s  %-10s  %-10s\n",
           "i","addr","addr/34","v1","v2");
    for(int i=0;i<10;i++){
        uint64_t a=make_addr(i);
        printf("  %-6d  %-8llu  %-6llu  %-10s  %-10s\n",
               i,(unsigned long long)a,
               (unsigned long long)(a/L38_GPU_SV),
               (a&1)?"MAIN":"TEMPORAL",
               ((a/L38_GPU_SV)&1)?"MAIN":"TEMPORAL");
    }

    /* twin check */
    printf("\nTwin (a↔A) with v2:\n");
    for(int i=0;i<4;i++){
        uint64_t a=make_addr(i), twin=~a;
        printf("  addr=%llu→%s  ~addr→%s  opposite=%s\n",
               (unsigned long long)a,
               ((a/L38_GPU_SV)&1)?"MAIN":"TEMPORAL",
               ((twin/L38_GPU_SV)&1)?"MAIN":"TEMPORAL",
               (((a/L38_GPU_SV)&1) != ((twin/L38_GPU_SV)&1))?"✓":"✗");
    }

    /* benchmark both */
    struct timespec t0,t1;
    int cnt1[3]={0}, cnt2[3]={0};
    uint64_t sink=0;

    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<N;i++){
        uint64_t a=make_addr(i), v=make_value(a);
        uint64_t c=v^a^(v>>32);
        cnt1[geo_route_v1(c,~c,a)]++; sink^=i;
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double ns1=((t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec))/N;

    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<N;i++){
        uint64_t a=make_addr(i), v=make_value(a);
        uint64_t c=v^a^(v>>32);
        cnt2[geo_route_v2(c,~c,a)]++; sink^=i;
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double ns2=((t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec))/N;

    printf("\nBenchmark (%dM ops, clean data):\n\n", N/1000000);
    printf("  v1 (addr&1):      MAIN=%-8d TEMPORAL=%-8d %.2fns  ← broken\n",
           cnt1[1],cnt1[2],ns1);
    printf("  v2 (addr/SV&1):   MAIN=%-8d TEMPORAL=%-8d %.2fns  ← fixed\n",
           cnt2[1],cnt2[2],ns2);

    printf("\n  MAIN/TEMPORAL split v2: %.1f%% / %.1f%%\n",
           cnt2[1]*100.0/N, cnt2[2]*100.0/N);
    printf("  sink: %llu\n",(unsigned long long)sink);

    /* corrupt test */
    printf("\nCorrupt detection (5%% injected):\n");
    int drop=0,pass=0;
    for(int i=0;i<N;i++){
        uint64_t a=make_addr(i), v=make_value(a);
        uint64_t c=v^a^(v>>32);
        uint64_t inv=(i%20==0)?~c^1ULL:~c;
        route_t r=geo_route_v2(c,inv,a);
        if(r==ROUTE_DROP) drop++; else pass++;
    }
    printf("  DROP=%d (%.1f%%)  PASS=%d  QRPN-saved=%.1f%%\n",
           drop,drop*100.0/N,pass,drop*100.0/N);

    return 0;
}
