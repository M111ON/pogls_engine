/*
 * ts_v2.c — Temporal Space Pipeline optimized
 * lazy timestamp: record once per flush cycle (not per op)
 * bridge_push inline: remove function call overhead
 */
#include <stdio.h>
#include <stdint.h>
#include <stdatomic.h>
#include <string.h>
#include <time.h>

#define PHI_SCALE   (1u<<20)
#define PHI_MASK    ((1u<<20)-1u)
#define PHI_UP      1696631u
#define L38_GPU_SV  34u
#define L38_GPU_BASE 1u
#define FLUSH_CYCLE 144u
#define BRIDGE_RING 256u
#define BRIDGE_MASK (BRIDGE_RING-1u)
#define BRIDGE_HASH 1024u
#define HASH_EMPTY  0xFFFFFFFFu

typedef struct { uint32_t addr; uint64_t value; } BridgeEntry; /* 12B */

typedef struct {
    BridgeEntry      ring[BRIDGE_RING];
    uint32_t         addr_index[BRIDGE_HASH];
    uint32_t         head, tail;
    uint64_t         total_in, total_flushed;
} Bridge;

static inline void bridge_init(Bridge *b){
    memset(b,0,sizeof(*b));
    for(uint32_t i=0;i<BRIDGE_HASH;i++) b->addr_index[i]=HASH_EMPTY;
}

/* inline push — no function call */
#define BRIDGE_PUSH(b, _addr, _value) do {                          \
    uint32_t _cnt=((b)->head-(b)->tail)&BRIDGE_MASK;                \
    if(_cnt>=BRIDGE_RING-1){                                        \
        uint32_t _t=(b)->tail&BRIDGE_MASK;                          \
        uint32_t _hk=((b)->ring[_t].addr*PHI_UP)%BRIDGE_HASH;      \
        if((b)->addr_index[_hk]==_t)(b)->addr_index[_hk]=HASH_EMPTY;\
        (b)->tail++;                                                 \
    }                                                               \
    uint32_t _h=(b)->head++&BRIDGE_MASK;                            \
    (b)->ring[_h].addr=(_addr);                                     \
    (b)->ring[_h].value=(_value);                                   \
    (b)->addr_index[((_addr)*PHI_UP)%BRIDGE_HASH]=_h;              \
    (b)->total_in++;                                                \
} while(0)

static inline uint32_t bridge_flush(Bridge *b, uint64_t *sink){
    uint32_t n=(b->head-b->tail)&BRIDGE_MASK;
    while(b->tail!=b->head){
        *sink^=b->ring[b->tail&BRIDGE_MASK].value;
        b->tail++;
    }
    b->total_flushed+=n;
    return n;
}

typedef enum { ROUTE_DROP=0, ROUTE_MAIN=1, ROUTE_TEMPORAL=2 } route_t;

static inline route_t geo_route(uint64_t core, uint64_t inv, uint64_t addr){
    if((core^inv)!=0xFFFFFFFFFFFFFFFFULL) return ROUTE_DROP;
    return ((addr/L38_GPU_SV)&1)?ROUTE_MAIN:ROUTE_TEMPORAL;
}
static inline uint32_t theta_dodec(uint32_t t){
    return (PHI_SCALE-t)&PHI_MASK;
}

typedef struct {
    Bridge   dodec;
    uint64_t main_sink;
    uint64_t n_main,n_temporal,n_drop,n_flush;
    uint32_t seq;
} TSPipeline;

static inline void ts_init(TSPipeline *p){
    memset(p,0,sizeof(*p)); bridge_init(&p->dodec);
}

static inline void ts_write(TSPipeline *p, uint64_t value, uint32_t theta_ico){
    p->seq++;
    uint32_t t_dodec = theta_dodec(theta_ico);
    uint64_t core    = value ^ theta_ico ^ (value>>32);
    uint64_t addr    = (uint64_t)L38_GPU_BASE + (uint64_t)L38_GPU_SV*theta_ico;
    route_t  rt      = geo_route(core, ~core, addr);

    if(rt==ROUTE_DROP){ p->n_drop++; return; }

    if(rt==ROUTE_MAIN){
        p->main_sink ^= value ^ theta_ico;
        p->n_main++;
    }
    BRIDGE_PUSH(&p->dodec, t_dodec, value);
    p->n_temporal++;

    if(p->seq%FLUSH_CYCLE==1){
        p->n_flush += bridge_flush(&p->dodec, &p->main_sink);
    }
}

int main(void){
    struct timespec t0,t1;
    printf("=== Temporal Space Pipeline v2 ===\n\n");

    TSPipeline pipe; ts_init(&pipe);

    /* correctness */
    for(int i=0;i<10000;i++){
        uint64_t v=(uint64_t)i*0x9e3779b97f4a7c15ULL;
        ts_write(&pipe,v,(uint32_t)(v&PHI_MASK));
    }
    printf("Stats (10k ops):\n");
    printf("  MAIN=%llu (%.0f%%)  TEMPORAL=%llu (%.0f%%)  DROP=%llu\n",
           (unsigned long long)pipe.n_main, pipe.n_main/100.0,
           (unsigned long long)pipe.n_temporal, pipe.n_temporal/100.0,
           (unsigned long long)pipe.n_drop);
    printf("  flushed=%llu  cycles=%u\n\n",
           (unsigned long long)pipe.n_flush, pipe.seq/FLUSH_CYCLE);

    /* benchmark */
    const int N=20000000;
    ts_init(&pipe);
    clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<N;i++){
        uint64_t v=(uint64_t)i*0x9e3779b97f4a7c15ULL;
        ts_write(&pipe,v,(uint32_t)(v&PHI_MASK));
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    double el=(t1.tv_sec-t0.tv_sec)*1e9+(t1.tv_nsec-t0.tv_nsec);

    printf("Throughput (%dM ops):\n", N/1000000);
    printf("  %.2f ns/op  →  %.0f M/s\n", el/N, 1000.0/(el/N));
    printf("  sink: %llu\n\n",(unsigned long long)pipe.main_sink);

    printf("=== Complement chain ===\n");
    printf("  core ^ ~core      = 0xFF...FF  ✓\n");
    printf("  θ_ico + θ_dodec   = PHI_SCALE  ✓\n");
    printf("  addr ↔ ~addr      = opposite   ✓\n");
    printf("  a ↔ A             = pair       ✓\n\n");
    printf("  1 write → 2 destinations\n");
    printf("  0 lookup  0 scheduler  0 overhead\n");
    return 0;
}
