/*
 * geo_route.h — Wireless Hilbert Router v2
 * 
 * Position in pipeline:
 *   [input] → geo_route() → MAIN/TEMPORAL/DROP
 *                               ↓
 *                         geo_net_route() → QRPN → delta
 *
 * Properties:
 *   MAIN:     (addr/SV) & 1 == 1  → ico  / pogls_write
 *   TEMPORAL: (addr/SV) & 1 == 0  → dodec / bridge
 *   DROP:     core ^ inv != 0xFF  → corrupt, discard
 *
 *   twin: addr ↔ ~addr always opposite path (a==A)
 *   cost: 3 ops, deterministic, no PHI scatter, no score
 */

#ifndef GEO_ROUTE_H
#define GEO_ROUTE_H

#include <stdint.h>
// NOTE: define L38_GPU_SV and POGLS_PHI_SCALE before including
// or include pogls_platform.h before this header

#ifndef L38_GPU_SV
#  define L38_GPU_SV  34u     /* Fib(9) — step vector FROZEN */
#endif

typedef enum {
    ROUTE_DROP     = 0,   /* corrupt block — discard, QRPN saved  */
    ROUTE_MAIN     = 1,   /* ico / POGLS delta lane                */
    ROUTE_TEMPORAL = 2,   /* dodec / temporal buffer               */
} geo_route_t;

/*
 * geo_route — 3 ops, deterministic
 *
 * @core  raw value block
 * @inv   must equal ~core (Wireless Hilbert entanglement)
 * @addr  angular address (from pogls_write path)
 */
static inline geo_route_t geo_route(uint64_t core,
                                     uint64_t inv,
                                     uint64_t addr)
{
    /* Step 1: integrity gate (1 XOR, free) */
    if ((core ^ inv) != 0xFFFFFFFFFFFFFFFFULL)
        return ROUTE_DROP;

    /* Step 2: route by step rhythm (addr/SV alternates 0,1,0,1...)
     * a (lower) → MAIN     (ico/POGLS)
     * A (upper) → TEMPORAL (dodec/buffer)              */
    return ((addr / L38_GPU_SV) & 1u)
           ? ROUTE_MAIN
           : ROUTE_TEMPORAL;
}

/* twin: ~addr always routes opposite — a==A by construction */
static inline geo_route_t geo_route_twin(uint64_t core,
                                          uint64_t inv,
                                          uint64_t addr)
{
    return geo_route(core, inv, ~addr);
}

#endif /* GEO_ROUTE_H */
