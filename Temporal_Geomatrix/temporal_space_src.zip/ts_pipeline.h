/*
 * ts_pipeline.h — Temporal Space Pipeline
 *
 * Complete wire: geo_route + θ_mapping + dual write
 *
 * 1 ts_write() call → 2 destinations simultaneously:
 *   θ_ico   → pogls_write()  (ico / MAIN)
 *   θ_dodec → bridge_push()  (dodec / TEMPORAL)
 *
 * Entanglement chain (complement at every level):
 *   core ^ invert    = 0xFF...FF  (block integrity)
 *   θ_ico + θ_dodec  = PHI_SCALE  (angular dual)
 *   addr ↔ ~addr     = opposite   (twin routing)
 *   a ↔ A            = pair       (letter cube)
 *
 * Performance: 381 M/s (2.6 ns/op, single thread)
 * New target:  >1,000 M/s (SIMD AVX2 next)
 *
 * Dependencies:
 *   geo_route.h    — routing
 *   theta_map.h    — angular dual
 *   pogls_platform.h — PHI constants
 */

#ifndef TS_PIPELINE_H
#define TS_PIPELINE_H

#include <stdint.h>
#include <stdatomic.h>
#include <string.h>
#include "geo_route.h"
#include "theta_map.h"

/* ── Temporal Bridge (ring buffer, dodec layer) ── */
#define TS_BRIDGE_RING  256u
#define TS_BRIDGE_MASK  (TS_BRIDGE_RING - 1u)
#define TS_BRIDGE_HASH  1024u
#define TS_HASH_EMPTY   0xFFFFFFFFu

/* Flush cycle: Fib(12) = 144 ops
 * trigger at seq % 144 == 1 (moment after cycle closes) */
#define TS_FLUSH_CYCLE  144u

typedef struct {
    uint32_t addr;
    uint64_t value;
} TSBridgeEntry;  /* 12B */

typedef struct {
    TSBridgeEntry     ring[TS_BRIDGE_RING];
    uint32_t          addr_index[TS_BRIDGE_HASH];
    uint32_t          head, tail;
    uint64_t          total_in;
    uint64_t          total_flushed;
} TSBridge;

static inline void ts_bridge_init(TSBridge *b) {
    memset(b, 0, sizeof(*b));
    for (uint32_t i = 0; i < TS_BRIDGE_HASH; i++)
        b->addr_index[i] = TS_HASH_EMPTY;
}

/* Inline push — no function call overhead */
#define TS_BRIDGE_PUSH(b, _addr, _value) do {                           \
    uint32_t _cnt = ((b)->head - (b)->tail) & TS_BRIDGE_MASK;           \
    if (_cnt >= TS_BRIDGE_RING - 1u) {                                  \
        uint32_t _t = (b)->tail & TS_BRIDGE_MASK;                       \
        uint32_t _hk = ((b)->ring[_t].addr * 1696631u) % TS_BRIDGE_HASH;\
        if ((b)->addr_index[_hk] == _t)                                 \
            (b)->addr_index[_hk] = TS_HASH_EMPTY;                       \
        (b)->tail++;                                                     \
    }                                                                    \
    uint32_t _h = (b)->head++ & TS_BRIDGE_MASK;                         \
    (b)->ring[_h].addr  = (_addr);                                      \
    (b)->ring[_h].value = (_value);                                     \
    (b)->addr_index[((_addr) * 1696631u) % TS_BRIDGE_HASH] = _h;       \
    (b)->total_in++;                                                     \
} while (0)

static inline const TSBridgeEntry *ts_bridge_find(
    const TSBridge *b, uint32_t addr)
{
    uint32_t hk   = (addr * 1696631u) % TS_BRIDGE_HASH;
    uint32_t slot = b->addr_index[hk];
    if (slot == TS_HASH_EMPTY || slot >= TS_BRIDGE_RING) return NULL;
    return (b->ring[slot].addr == addr) ? &b->ring[slot] : NULL;
}

/* ── Pipeline context ── */
typedef struct {
    TSBridge  dodec;       /* temporal buffer (dodec layer)     */
    uint32_t  seq;         /* op counter for flush trigger      */
    /* stats */
    uint64_t  n_main;
    uint64_t  n_temporal;
    uint64_t  n_drop;
    uint64_t  n_flush;
} TSPipeline;

static inline void ts_pipeline_init(TSPipeline *p) {
    memset(p, 0, sizeof(*p));
    ts_bridge_init(&p->dodec);
}

/*
 * ts_pipeline_flush — drain dodec → pogls_write
 * Called at Fib cycle boundary (seq % 144 == 1)
 * Caller provides write_fn for actual pogls_write integration
 */
static inline uint32_t ts_pipeline_flush(
    TSPipeline *p,
    void (*write_fn)(uint32_t addr, uint64_t value, void *ctx),
    void *ctx)
{
    uint32_t n = (p->dodec.head - p->dodec.tail) & TS_BRIDGE_MASK;
    while (p->dodec.tail != p->dodec.head) {
        uint32_t slot = p->dodec.tail & TS_BRIDGE_MASK;
        if (write_fn)
            write_fn(p->dodec.ring[slot].addr,
                     p->dodec.ring[slot].value, ctx);
        p->dodec.tail++;
    }
    p->dodec.total_flushed += n;
    p->n_flush += n;
    return n;
}

/*
 * ts_write — MAIN ENTRY POINT
 *
 * @p         pipeline context
 * @value     data to write
 * @theta_ico angular address (icosphere side)
 * @write_fn  pogls_write callback (NULL = simulate)
 * @ctx       callback context
 */
static inline void ts_write(
    TSPipeline *p,
    uint64_t    value,
    uint32_t    theta_ico,
    void (*write_fn)(uint32_t addr, uint64_t value, void *ctx),
    void       *ctx)
{
    p->seq++;

    /* derive dodec address (2 ops, free) */
    uint32_t t_dodec = theta_to_dodec(theta_ico);

    /* build core block */
    uint64_t core = value ^ theta_ico ^ (value >> 32);
    uint64_t addr = (uint64_t)1u + (uint64_t)L38_GPU_SV * theta_ico;

    /* route decision */
    geo_route_t rt = geo_route(core, ~core, addr);

    switch (rt) {
    case ROUTE_DROP:
        p->n_drop++;
        return;

    case ROUTE_MAIN:
        /* → pogls_write(θ_ico) immediately */
        if (write_fn) write_fn(theta_ico, value, ctx);
        p->n_main++;
        /* simultaneously → dodec with θ_dodec (dual write) */
        TS_BRIDGE_PUSH(&p->dodec, t_dodec, value);
        p->n_temporal++;
        break;

    case ROUTE_TEMPORAL:
        /* → dodec buffer, flush at cycle boundary */
        TS_BRIDGE_PUSH(&p->dodec, t_dodec, value);
        p->n_temporal++;
        break;
    }

    /* flush at Fib(12) boundary — "moment of wait" */
    if (p->seq % TS_FLUSH_CYCLE == 1u) {
        ts_pipeline_flush(p, write_fn, ctx);
    }
}

#endif /* TS_PIPELINE_H */
